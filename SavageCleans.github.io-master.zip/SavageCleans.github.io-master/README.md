**Fun games remade playable in the browser!**

**Games Links**

Dinosaur Game: https://SavageCleans.github.io/DinosaurGame.html

Snake Game https://SavageCleans.github.io/Snake.html
